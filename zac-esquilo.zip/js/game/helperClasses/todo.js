/*
A idéia agora é focar no desenvolvimento novamente sim. Sugiro esta ordem:

Implementar a lógica de vidas (não me lembro, acho que ainda faltava alguma coisinha)
Implementar lógica de vitória (chegar lá em cima)/derrota perder X vidas e voltar ao menu)
Fazer o jogador perder vida ao cair na água
Implementar o algoritmo one-switch para a cena de jogo
Desenhar os gráficos finais
Trocar os gráficos provisórios pelos finais
Fazer a tela de opções, modo normal e modo one-switch
Centralizar/redimensionar a tela de jogo
Colocar música/efeitos sonoros
Externalizar a configuração do mapa
Possibilitar que haja mais de uma fase, em sequência

Me dê notícias do seu progresso. Se você precisar encontrar um dia, podemos marcar.

*/
