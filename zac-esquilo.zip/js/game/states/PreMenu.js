ZacEsquilo.PreMenu = function() {};

ZacEsquilo.PreMenu.prototype = {
  preload: function(){
    this.load.spritesheet('oneSwitchOn', 'assets/images/buttons/accessibleOn.png', 189, 58, 2);
    this.load.spritesheet('oneSwitchOff', 'assets/images/buttons/accessibleOff.png', 189, 58, 2);
  },

  create: function(){
    ZacEsquilo.switchOn = this.game.add.button(this.game.world.centerX - 250, this.game.world.centerY, 'oneSwitchOn', this.playAccessible, this, 1, 0);
    ZacEsquilo.switchOff = this.game.add.button(this.game.world.centerX + 150 , this.game.world.centerY, 'oneSwitchOff', this.playNormal, this, 1, 0);

    this.createText();

    ZacEsquilo.switchOn.onInputOver.add(this.over,this);
    ZacEsquilo.switchOn.onInputOut.add(this.out,this);

    // this.game.time.events.add(1000, function() { ZacEsquilo.switchOn.frame = 1; }, this);


    ZacEsquilo.switchOff.onInputOver.add(this.over,this);
    ZacEsquilo.switchOff.onInputOut.add(this.out,this);


    this.game.time.events.add(500, function(){
      ZacEsquilo.switchOn;
    }, this);

    // ZacEsquilo.switchOn.frame = 1;

    // instanciar um oneswitchmanager
    var oneswitchmanager = new ZacEsquilo.OneSwitchManager([
      ZacEsquilo.switchOn,
      ZacEsquilo.switchOff
    ], 2, this.game);
    oneswitchmanager.start();
  },

  createText: function() {
    ZacEsquilo.switchText = null;

    // this.fontStyle = { font: "20px Arial", fill: "#330033", align: "center"};
    this.fontStyle = { font: "25px Sigmar One", fill: "#330033", align: "center"};

    var switchQuestion = "O modo de jogo acessível (One Switch) está ativado. \n Pressione a barra de espaço para \n selecionar a opção desejada. "

    ZacEsquilo.switchText = this.game.add.text(this.game.world.centerX, this.game.world.centerY/2, switchQuestion, this.fontStyle);
    ZacEsquilo.switchText.anchor.setTo(0.5);
    ZacEsquilo.switchText.wordWrap = true;
    ZacEsquilo.switchText.wordWrapWidth = window.innerWidth - 20;
  },

  over: function() {
  },

  out: function() {
  },

  playAccessible: function() {
    this.state.start('MainMenu');
  },

  playNormal: function() {
    ZacEsquilo.config.oneSwitchActive = false;
    this.state.start('MainMenu');
  }
};
